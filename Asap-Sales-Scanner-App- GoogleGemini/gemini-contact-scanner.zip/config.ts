// IMPORTANT: You must create your own Google Cloud project and obtain an OAuth 2.0 Client ID.
// 1. Go to https://console.cloud.google.com/
// 2. Create a new project.
// 3. Go to "APIs & Services" > "Credentials".
// 4. Click "Create Credentials" > "OAuth client ID".
// 5. Select "Web application".
// 6. Under "Authorized JavaScript origins", add the URL where you are running this app (e.g., http://localhost:3000).
// 7. Copy the "Client ID" and paste it below.

// This placeholder WILL NOT WORK. You must replace it.
export const GOOGLE_CLIENT_ID = "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com";
