
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfileData, ContactInfo } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    businessName: { type: Type.STRING, description: "The name of the business or organization." },
    personName: { type: Type.STRING, description: "The full name of the contact person." },
    designation: { type: Type.STRING, description: "The job title or designation of the person." },
    phoneNumber: { type: Type.STRING, description: "The primary contact phone number." },
    email: { type: Type.STRING, description: "The primary contact email address." },
    website: { type: Type.STRING, description: "The business website URL." },
    socialMedia: {
      type: Type.ARRAY,
      description: "A list of social media profile URLs (e.g., LinkedIn, Twitter).",
      items: { type: Type.STRING }
    },
    industry: { type: Type.STRING, description: "The industry or sector the business operates in." },
    notes: { type: Type.STRING, description: "Any other relevant information that could help categorize the business or personalize a message." },
    generatedEmail: {
        type: Type.STRING,
        description: "A professional and friendly introductory email based on the user's profile and the extracted contact information. It should be ready to send."
    },
    generatedSms: {
        type: Type.STRING,
        description: "A concise and friendly introductory SMS/WhatsApp message based on the user's profile and the extracted contact information. It should be ready to send."
    }
  },
};

export const extractAndGenerate = async (imageBase64: string, userProfile: UserProfileData): Promise<ContactInfo> => {
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: imageBase64,
    },
  };
  
  const textPart = {
    text: `
      Analyze the attached image (which could be a business card, sign, or screenshot).
      Extract the contact and business information as precisely as possible.
      
      Then, using the extracted information and my profile below, generate a bespoke email and a SMS/WhatsApp message for outreach.

      My Profile:
      - My Business: ${userProfile.businessName}
      - My Products/Services: ${userProfile.businessDetails}
      - My Goal: ${userProfile.outreachGoal}

      Your task is to return a JSON object containing both the extracted information and the generated messages.
    `,
  };

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: { parts: [imagePart, textPart] },
    config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
    },
  });

  const jsonString = response.text.trim();
  try {
    const parsedJson = JSON.parse(jsonString);
    return parsedJson as ContactInfo;
  } catch (e) {
    console.error("Failed to parse JSON response from Gemini:", jsonString);
    throw new Error("Received an invalid response from the AI model.");
  }
};
