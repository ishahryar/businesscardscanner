import { ContactInfo, Crm } from '../types';

// This is a simulated service. In a real application, this would involve
// OAuth authentication and actual API calls to the respective CRM services.

const simulateApiCall = (crmName: string, contactName?: string): Promise<{ success: boolean; message: string }> => {
  console.log(`Simulating sync with ${crmName} for:`, contactName);
  return new Promise(resolve => {
    setTimeout(() => {
      // Randomly simulate success or failure for demonstration
      if (Math.random() > 0.1) { // 90% success rate
        resolve({
          success: true,
          message: `Successfully synced ${contactName || 'contact'} to ${crmName}.`
        });
      } else {
        resolve({
          success: false,
          message: `Failed to sync contact to ${crmName}. Please try again.`
        });
      }
    }, 1500); // Simulate network latency
  });
};


export const syncToCrm = async (
  contact: ContactInfo,
  crm: Crm
): Promise<{ success: boolean; message: string }> => {
  if (!contact.personName && !contact.businessName) {
    throw new Error("Cannot sync contact without a name or business name.");
  }

  const contactIdentifier = contact.personName || contact.businessName;

  switch (crm) {
    case Crm.HUBSPOT:
      return simulateApiCall('HubSpot', contactIdentifier);
    case Crm.SALESFORCE:
      return simulateApiCall('Salesforce', contactIdentifier);
    case Crm.GOOGLE_CONTACTS:
        return simulateApiCall('Google Contacts', contactIdentifier);
    case Crm.NONE:
      throw new Error("Please select a CRM system to sync to.");
    default:
      throw new Error("Unsupported CRM system.");
  }
};
