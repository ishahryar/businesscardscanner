import { ContactInfo, TokenClient } from '../types';

// This is a REAL integration with the Gmail API using client-side OAuth.
// Note: The GAPI script must be loaded in index.html for `gapi` to be available.
declare const gapi: any;

const createRfc2822Message = (from: string, to: string, subject: string, body: string): string => {
  const emailLines = [];
  // Use a proper Content-Type for HTML emails
  emailLines.push(`From: <${from}>`);
  emailLines.push(`To: <${to}>`);
  emailLines.push('Content-type: text/html;charset=utf-8');
  emailLines.push('MIME-Version: 1.0');
  emailLines.push(`Subject: ${subject}`);
  emailLines.push('');
  emailLines.push(body.replace(/\n/g, '<br>')); // Basic newline to HTML conversion

  const email = emailLines.join('\r\n');
  
  // The 'raw' message for the Gmail API needs to be Base64url encoded
  return btoa(unescape(encodeURIComponent(email))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};

export const createGmailDraft = async (
  contact: ContactInfo,
  emailBody: string,
  fromEmail: string,
  tokenClient: TokenClient
): Promise<{ success:boolean; message: string }> => {
  if (!contact.email) {
    return { success: false, message: "Contact has no email address." };
  }
  if (!emailBody) {
    return { success: false, message: "Email body is empty." };
  }
  if (!fromEmail) {
    return { success: false, message: "Sender email is not configured." };
  }
  if (!gapi || !gapi.client || !gapi.client.gmail) {
    return { success: false, message: "Google API client not loaded or initialized." };
  }
  
  const subject = `Following up from ${contact.businessName || 'our meeting'}`;
  const rawMessage = createRfc2822Message(fromEmail, contact.email, subject, emailBody);

  return new Promise((resolve) => {
    // Request a token. This will show a consent popup if permissions haven't been granted.
    tokenClient.callback = async (resp) => {
        if (resp.error !== undefined) {
            console.error('Google token error:', resp.error);
            resolve({ success: false, message: `Google Auth Error: ${resp.error}` });
            return;
        }

        try {
            // FIX: Set the access token for the GAPI client. This is the crucial step
            // that authorizes the subsequent API call.
            gapi.client.setToken({ access_token: resp.access_token });
            
            const response = await gapi.client.gmail.users.drafts.create({
                userId: 'me',
                resource: {
                    message: {
                        raw: rawMessage,
                    },
                },
            });
            
            if (response.result.id) {
                resolve({ success: true, message: "Email draft successfully created in your Gmail." });
            } else {
                 resolve({ success: false, message: "Failed to create draft. Response was empty." });
            }

        } catch (err: any) {
            console.error('Gmail API Error:', err);
            const errorMessage = err.result?.error?.message || "An unknown error occurred with the Gmail API.";
            resolve({ success: false, message: `Gmail API Error: ${errorMessage}` });
        }
    };
    // Use 'consent' prompt to ensure the user is asked for permission the first time.
    tokenClient.requestAccessToken({ prompt: 'consent' });
  });
};