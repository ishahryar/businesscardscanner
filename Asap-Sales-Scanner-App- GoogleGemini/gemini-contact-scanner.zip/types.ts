export enum AppState {
  SETUP_REQUIRED = 'SETUP_REQUIRED',
  CONNECTIONS = 'CONNECTIONS',
  PROFILE = 'PROFILE',
  CAPTURE = 'CAPTURE',
  PROCESSING = 'PROCESSING',
  RESULTS = 'RESULTS',
}

// Fix: Declare google namespace to resolve type errors.
// This provides types for the Google Identity Services library.
declare namespace google {
  namespace accounts {
    namespace id {
      function initialize(config: { client_id: string; callback: (response: any) => void; }): void;
      function renderButton(
        parent: HTMLElement,
        options: { theme: string; size: string; type: string; text: string; }
      ): void;
    }
    namespace oauth2 {
      function initTokenClient(config: {
        client_id: string;
        scope: string;
        callback: string | ((...args: any[]) => void);
      }): TokenClient;
      
      interface TokenClient {
        callback: (response: any) => void;
        requestAccessToken: (options?: { prompt?: string }) => void;
      }
    }
  }
}

export interface UserProfileData {
  businessName: string;
  businessDetails: string;
  outreachGoal: string;
}

export interface ContactInfo {
  businessName?: string;
  personName?: string;
  designation?: string;
  phoneNumber?: string;
  email?: string;
  website?: string;
  socialMedia?: string[];
  industry?: string;
  notes?: string;
  generatedEmail?: string;
  generatedSms?: string;
}



export enum Crm {
  NONE = 'Select CRM',
  HUBSPOT = 'HubSpot',
  SALESFORCE = 'Salesforce',
  GOOGLE_CONTACTS = 'Google Contacts',
}

export interface GoogleUser {
    email: string;
    name: string;
    picture: string;
}

// This type comes from the Google Identity Services library.
// Defining it here for use in component props.
export type TokenClient = google.accounts.oauth2.TokenClient;