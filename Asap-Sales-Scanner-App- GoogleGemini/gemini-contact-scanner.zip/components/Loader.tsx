
import React from 'react';
import SparklesIcon from './icons/SparklesIcon';

interface LoaderProps {
  message?: string;
}

const Loader: React.FC<LoaderProps> = ({ message = 'Loading...' }) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 bg-dark-card border border-dark-border rounded-lg animate-fade-in">
        <SparklesIcon className="w-12 h-12 text-brand-secondary animate-pulse" />
        <p className="mt-4 text-lg font-semibold text-white">{message}</p>
        <p className="text-sm text-dark-text-secondary">Please wait a moment.</p>
    </div>
  );
};

export default Loader;
