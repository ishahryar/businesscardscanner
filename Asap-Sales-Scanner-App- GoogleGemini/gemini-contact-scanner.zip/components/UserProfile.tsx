
import React, { useState } from 'react';
import { UserProfileData } from '../types';

interface UserProfileProps {
  onSubmit: (data: UserProfileData) => void;
  initialData: UserProfileData | null;
}

const UserProfile: React.FC<UserProfileProps> = ({ onSubmit, initialData }) => {
  const [formData, setFormData] = useState<UserProfileData>(
    initialData || {
      businessName: '',
      businessDetails: '',
      outreachGoal: '',
    }
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  const isFormValid = formData.businessName && formData.businessDetails && formData.outreachGoal;

  return (
    <div className="bg-dark-card border border-dark-border rounded-lg p-6 sm:p-8 animate-fade-in">
      <h2 className="text-2xl font-bold mb-2 text-white">Your Profile</h2>
      <p className="text-dark-text-secondary mb-6">This information helps Gemini craft personalized messages for you.</p>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="businessName" className="block text-sm font-medium text-dark-text-secondary mb-1">Your Business Name</label>
          <input
            type="text"
            id="businessName"
            name="businessName"
            value={formData.businessName}
            onChange={handleChange}
            placeholder="e.g., Innovate Solutions Inc."
            className="w-full bg-gray-800 border border-dark-border rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-brand-primary focus:border-brand-primary transition"
            required
          />
        </div>
        <div>
          <label htmlFor="businessDetails" className="block text-sm font-medium text-dark-text-secondary mb-1">Your Products/Services</label>
          <textarea
            id="businessDetails"
            name="businessDetails"
            value={formData.businessDetails}
            onChange={handleChange}
            rows={4}
            placeholder="Describe what you sell or offer. e.g., We provide AI-driven analytics dashboards for e-commerce businesses."
            className="w-full bg-gray-800 border border-dark-border rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-brand-primary focus:border-brand-primary transition"
            required
          />
        </div>
        <div>
          <label htmlFor="outreachGoal" className="block text-sm font-medium text-dark-text-secondary mb-1">Your Outreach Goal</label>
          <textarea
            id="outreachGoal"
            name="outreachGoal"
            value={formData.outreachGoal}
            onChange={handleChange}
            rows={2}
            placeholder="What is the primary action you want the new contact to take? e.g., Schedule a 15-minute demo call to showcase our product."
            className="w-full bg-gray-800 border border-dark-border rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-brand-primary focus:border-brand-primary transition"
            required
          />
        </div>
        <button
          type="submit"
          disabled={!isFormValid}
          className="w-full bg-brand-primary hover:bg-brand-primary/90 text-white font-bold py-3 px-4 rounded-md transition-all duration-300 disabled:bg-gray-600 disabled:cursor-not-allowed"
        >
          Save & Continue
        </button>
      </form>
    </div>
  );
};

export default UserProfile;
