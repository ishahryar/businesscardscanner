import React from 'react';

const SetupInstructions: React.FC = () => {
  return (
    <div className="bg-dark-card border border-dark-border rounded-lg p-6 sm:p-8 animate-fade-in text-left">
      <h2 className="text-2xl font-bold mb-3 text-white">One-Time Setup Required</h2>
      <p className="text-dark-text-secondary mb-6">
        To connect to your personal Google account, this application first needs a unique key (a "Client ID") from Google. This is a security measure required by Google for all third-party apps.
      </p>

      <div className="space-y-4 text-dark-text">
        <h3 className="text-lg font-semibold text-brand-primary">Follow these steps:</h3>
        <ol className="list-decimal list-inside space-y-3 bg-gray-800 p-4 rounded-lg">
          <li>
            Go to the Google Cloud Console: 
            <a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline ml-1">
              console.cloud.google.com
            </a>
          </li>
          <li>If prompted, create a <span className="font-semibold text-white">New Project</span>.</li>
          <li>
            In the top search bar, find and select
            <span className="font-semibold text-white"> "APIs & Services"</span>.
          </li>
          <li>
            On the left menu, click 
            <span className="font-semibold text-white"> "Credentials"</span>.
          </li>
          <li>
            Click <span className="font-semibold text-white">"+ CREATE CREDENTIALS"</span> at the top, and choose
            <span className="font-semibold text-white"> "OAuth client ID"</span>.
          </li>
          <li>
            For "Application type", select 
            <span className="font-semibold text-white"> "Web application"</span>.
          </li>
          <li>
            Under "Authorized JavaScript origins", click <span className="font-semibold text-white">"+ ADD URI"</span> and enter the URL where you're running this app (e.g., <code className="bg-gray-700 px-1 rounded">http://localhost:5173</code> or the live URL).
          </li>
          <li>Click <span className="font-semibold text-white">"CREATE"</span>. A popup will show your Client ID.</li>
        </ol>

        <h3 className="text-lg font-semibold text-brand-primary pt-4">Final Step:</h3>
        <p>
          Copy the <span className="font-semibold text-white">Client ID</span> from the popup. Open the `config.ts` file in the project, paste your ID in place of the placeholder text, and then refresh this page.
        </p>
      </div>
    </div>
  );
};

export default SetupInstructions;
