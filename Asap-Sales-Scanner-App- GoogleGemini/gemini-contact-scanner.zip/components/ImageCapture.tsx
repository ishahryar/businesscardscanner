
import React, { useState, useRef, useCallback } from 'react';
import CameraIcon from './icons/CameraIcon';
import UploadIcon from './icons/UploadIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface ImageCaptureProps {
  onCapture: (imageBase64: string) => void;
  onEditProfile: () => void;
}

const ImageCapture: React.FC<ImageCaptureProps> = ({ onCapture, onEditProfile }) => {
  const [useCamera, setUseCamera] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setUseCamera(true);
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Could not access camera. Please ensure you've given permission and are using a secure (HTTPS) connection.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    setStream(null);
    setUseCamera(false);
  }, [stream]);

  const handleTakePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      context?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
      const dataUrl = canvas.toDataURL('image/jpeg');
      onCapture(dataUrl.split(',')[1]);
      stopCamera();
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = (e.target?.result as string).split(',')[1];
        onCapture(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-dark-card border border-dark-border rounded-lg p-6 sm:p-8 w-full animate-fade-in">
        <button onClick={onEditProfile} className="flex items-center gap-2 text-sm text-brand-primary hover:underline mb-4">
            <ArrowLeftIcon className="w-4 h-4" />
            Edit Profile
        </button>
      {useCamera ? (
        <div className="flex flex-col items-center">
          <div className="relative w-full max-w-md bg-gray-900 rounded-lg overflow-hidden border border-dark-border">
             <video ref={videoRef} autoPlay playsInline className="w-full h-auto" />
             <canvas ref={canvasRef} className="hidden" />
          </div>
          <div className="flex gap-4 mt-4">
            <button
              onClick={handleTakePhoto}
              className="flex-grow bg-brand-primary hover:bg-brand-primary/90 text-white font-bold py-3 px-6 rounded-md transition"
            >
              Scan
            </button>
            <button
              onClick={stopCamera}
              className="flex-grow bg-gray-600 hover:bg-gray-500 text-white font-bold py-3 px-6 rounded-md transition"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col md:flex-row gap-6">
          <button
            onClick={startCamera}
            className="flex-1 flex flex-col items-center justify-center p-8 bg-gray-800 hover:bg-gray-700 border-2 border-dashed border-dark-border rounded-lg transition-all"
          >
            <CameraIcon className="w-12 h-12 text-dark-text-secondary mb-3" />
            <span className="text-lg font-semibold">Use Camera</span>
            <span className="text-sm text-dark-text-secondary">Scan a business card or sign</span>
          </button>
          
          <div className="relative flex-1 flex flex-col items-center justify-center p-8 bg-gray-800 hover:bg-gray-700 border-2 border-dashed border-dark-border rounded-lg transition-all">
            <UploadIcon className="w-12 h-12 text-dark-text-secondary mb-3" />
            <span className="text-lg font-semibold">Upload Image</span>
            <span className="text-sm text-dark-text-secondary">Choose a file from your device</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageCapture;
