import React, { useState } from 'react';
import { ContactInfo, Crm, GoogleUser, TokenClient } from '../types';
import ClipboardIcon from './icons/ClipboardIcon';
import MessageIcon from './icons/MessageIcon';
import { syncToCrm } from '../services/crmService';
import { createGmailDraft } from '../services/messagingService';
import SpinnerIcon from './icons/SpinnerIcon';
import PaperPlaneIcon from './icons/PaperPlaneIcon';

// Re-usable component for displaying a field
const InfoField: React.FC<{ label: string; value?: string | string[] }> = ({ label, value }) => {
  if (!value || (Array.isArray(value) && value.length === 0)) return null;

  const renderValue = () => {
    if (Array.isArray(value)) {
      return value.map((item, index) => <div key={index} className="truncate">{item}</div>);
    }
    if (label.toLowerCase() === 'website' && (value.startsWith('http') || value.startsWith('www'))) {
      const url = value.startsWith('http') ? value : `https://${value}`;
      return <a href={url} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline truncate">{value}</a>;
    }
    return <span className="truncate">{value}</span>;
  };

  return (
    <div className="py-2">
      <p className="text-sm text-dark-text-secondary">{label}</p>
      <div className="text-base text-white font-medium">{renderValue()}</div>
    </div>
  );
};

// Re-usable card for actions like email/sms
const ActionCard: React.FC<{ title: string; content?: string; children: React.ReactNode }> = ({ title, content, children }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (content) {
      navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg flex flex-col">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        {content && (
          <button onClick={handleCopy} title="Copy content" className="p-2 rounded-md bg-gray-700 hover:bg-gray-600 transition text-dark-text">
            {copied ? <span className="text-sm text-green-400">Copied!</span> : <ClipboardIcon className="w-5 h-5" />}
          </button>
        )}
      </div>
      <p className="text-dark-text-secondary whitespace-pre-wrap bg-gray-900/50 p-3 rounded-md text-sm mb-4 flex-grow min-h-[100px]">
        {content || `No ${title.toLowerCase()} generated.`}
      </p>
      {children}
    </div>
  );
};

// CRM Integration Component
const CrmIntegration: React.FC<{ contact: ContactInfo }> = ({ contact }) => {
  const [selectedCrm, setSelectedCrm] = useState<Crm>(Crm.NONE);
  const [syncStatus, setSyncStatus] = useState({ loading: false, message: '', success: false });

  const handleCrmSync = async () => {
    if (selectedCrm === Crm.NONE) {
      setSyncStatus({ loading: false, message: 'Please select a CRM.', success: false });
      return;
    }
    setSyncStatus({ loading: true, message: '', success: false });
    const result = await syncToCrm(contact, selectedCrm);
    setSyncStatus({ loading: false, message: result.message, success: result.success });
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg">
      <h3 className="text-lg font-semibold text-white mb-2">CRM Integration</h3>
      <div className="flex flex-col sm:flex-row gap-2">
        <select
          value={selectedCrm}
          onChange={(e) => setSelectedCrm(e.target.value as Crm)}
          className="flex-grow bg-gray-900 border border-dark-border rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-brand-primary"
        >
          {Object.values(Crm).map(crm => <option key={crm} value={crm}>{crm}</option>)}
        </select>
        <button
          onClick={handleCrmSync}
          disabled={syncStatus.loading || selectedCrm === Crm.NONE}
          className="w-full sm:w-36 flex items-center justify-center bg-brand-secondary hover:bg-brand-secondary/90 text-white font-bold py-2 px-4 rounded-md transition disabled:bg-gray-600"
        >
          {syncStatus.loading ? <SpinnerIcon className="animate-spin h-5 w-5" /> : 'Sync Contact'}
        </button>
      </div>
      {syncStatus.message && (
        <p className={`text-sm mt-3 ${syncStatus.success ? 'text-green-400' : 'text-red-400'}`}>
          {syncStatus.message}
        </p>
      )}
    </div>
  );
};

interface ResultsDisplayProps {
  data: ContactInfo;
  onReset: () => void;
  googleUser: GoogleUser;
  tokenClient: TokenClient;
  gapiReady: boolean;
}

// Main Component
const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ data, onReset, googleUser, tokenClient, gapiReady }) => {
  const [draftStatus, setDraftStatus] = useState({ loading: false, message: '', success: false });

  const handleCreateDraft = async () => {
    if (!data.generatedEmail) return;
    setDraftStatus({ loading: true, message: '', success: false });
    const result = await createGmailDraft(data, data.generatedEmail, googleUser.email, tokenClient);
    setDraftStatus({ loading: false, message: result.message, success: result.success });
  };

  const whatsAppLink = data.phoneNumber && data.generatedSms
    ? `https://wa.me/${data.phoneNumber.replace(/\D/g, '')}?text=${encodeURIComponent(data.generatedSms)}`
    : '#';

  const isDraftButtonDisabled = !data.generatedEmail || !gapiReady || draftStatus.loading || draftStatus.success;

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Contact Info */}
        <div className="lg:col-span-1 bg-dark-card border border-dark-border rounded-lg p-6">
          <h2 className="text-2xl font-bold mb-4 text-white">Extracted Information</h2>
          <div className="divide-y divide-dark-border">
            <InfoField label="Person Name" value={data.personName} />
            <InfoField label="Designation" value={data.designation} />
            <InfoField label="Business Name" value={data.businessName} />
            <InfoField label="Email" value={data.email} />
            <InfoField label="Phone Number" value={data.phoneNumber} />
            <InfoField label="Website" value={data.website} />
            <InfoField label="Industry" value={data.industry} />
            <InfoField label="Social Media" value={data.socialMedia} />
            <InfoField label="Notes" value={data.notes} />
          </div>
        </div>

        {/* Actions */}
        <div className="lg:col-span-2 space-y-6">
          <ActionCard title="Generated Email" content={data.generatedEmail}>
             <button
              onClick={handleCreateDraft}
              disabled={isDraftButtonDisabled}
              title={!gapiReady ? "Google services are initializing..." : ""}
              className="w-full flex items-center justify-center gap-2 bg-brand-primary hover:bg-brand-primary/90 text-white font-bold py-2 px-4 rounded-md transition disabled:bg-gray-600 disabled:cursor-not-allowed"
             >
                {draftStatus.loading ? <SpinnerIcon className="animate-spin h-5 w-5" /> : <PaperPlaneIcon className="h-5 w-5" />}
                {draftStatus.success ? 'Draft Created!' : 'Create Draft in Gmail'}
             </button>
             {draftStatus.message && (
                <p className={`text-xs text-center mt-2 ${draftStatus.success ? 'text-green-400' : 'text-red-400'}`}>
                    {draftStatus.message}
                </p>
             )}
              {draftStatus.success && <p className="text-xs text-center text-dark-text-secondary mt-1">From: {googleUser.email}</p>}
          </ActionCard>
          
          <ActionCard title="Generated SMS / WhatsApp" content={data.generatedSms}>
            <a
              href={whatsAppLink}
              target="_blank"
              rel="noopener noreferrer"
              className={`w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-md transition ${!data.phoneNumber || !data.generatedSms ? 'opacity-50 cursor-not-allowed' : ''}`}
              onClick={(e) => { if (!data.phoneNumber || !data.generatedSms) e.preventDefault(); }}
            >
              <MessageIcon className="w-5 h-5" />
              Send via WhatsApp
            </a>
          </ActionCard>
          
          <CrmIntegration contact={data} />
        </div>
      </div>

      <div className="text-center">
        <button
          onClick={onReset}
          className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-3 px-8 rounded-md transition"
        >
          Scan Another
        </button>
      </div>
    </div>
  );
};

export default ResultsDisplay;