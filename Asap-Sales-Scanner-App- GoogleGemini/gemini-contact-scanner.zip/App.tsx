import React, { useState, useCallback, useEffect } from 'react';
import { UserProfileData, ContactInfo, AppState, GoogleUser, TokenClient } from './types';
import UserProfile from './components/UserProfile';
import ImageCapture from './components/ImageCapture';
import ResultsDisplay from './components/ResultsDisplay';
import Loader from './components/Loader';
import ConnectAccounts from './components/ConnectAccounts';
import SetupInstructions from './components/SetupInstructions'; // New component
import { extractAndGenerate } from './services/geminiService';
import SparklesIcon from './components/icons/SparklesIcon';
import { GOOGLE_CLIENT_ID } from './config'; // Import the ID

// This is required for the gapi script loaded in index.html
declare const gapi: any;

const App: React.FC = () => {
  // Check for placeholder Client ID and set the initial state accordingly.
  const isSetupRequired = !GOOGLE_CLIENT_ID || GOOGLE_CLIENT_ID.includes("YOUR_GOOGLE_CLIENT_ID");
  const [appState, setAppState] = useState<AppState>(
    isSetupRequired ? AppState.SETUP_REQUIRED : AppState.CONNECTIONS
  );

  const [userProfile, setUserProfile] = useState<UserProfileData | null>(null);
  const [googleUser, setGoogleUser] = useState<GoogleUser | null>(null);
  const [tokenClient, setTokenClient] = useState<TokenClient | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<ContactInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [gapiReady, setGapiReady] = useState(false);

  useEffect(() => {
    if (isSetupRequired) return; // Don't initialize GAPI if setup is needed.

    // This effect initializes the Google API client, which is necessary for the Gmail API.
    const initializeGapiClient = async () => {
      try {
        await new Promise<void>((resolve) => gapi.load('client', resolve));
        await gapi.client.init({
          // Discovery docs tell the client how to interact with the Gmail API.
          discoveryDocs: ['https://www.googleapis.com/discovery/v1/apis/gmail/v1/rest'],
        });
        setGapiReady(true);
      } catch (e) {
        console.error("Error initializing GAPI client", e);
        setError("Could not initialize connection to Google services. Please refresh the page.")
      }
    };

    if (typeof gapi !== 'undefined') {
      initializeGapiClient();
    }
  }, [isSetupRequired]);

  const handleConnectionsComplete = (user: GoogleUser, client: TokenClient) => {
    setGoogleUser(user);
    setTokenClient(client);
    setAppState(AppState.PROFILE);
  };

  const handleProfileSubmit = (data: UserProfileData) => {
    setUserProfile(data);
    setAppState(AppState.CAPTURE);
  };

  const handleImageCapture = useCallback(async (imageBase64: string) => {
    if (!userProfile) {
      setError("User profile is not set. Please go back and fill it out.");
      setAppState(AppState.PROFILE);
      return;
    }
    setCapturedImage(imageBase64);
    setAppState(AppState.PROCESSING);
    setError(null);

    try {
      const result = await extractAndGenerate(imageBase64, userProfile);
      setExtractedData(result);
      setAppState(AppState.RESULTS);
    } catch (err) {
      console.error(err);
      setError("Failed to process the image. The AI model might be busy. Please try again.");
      setAppState(AppState.CAPTURE);
    }
  }, [userProfile]);
  
  const handleReset = () => {
    setAppState(AppState.CAPTURE);
    setCapturedImage(null);
    setExtractedData(null);
    setError(null);
  };
  
  const handleProfileEdit = () => {
    setAppState(AppState.PROFILE);
  };

  const renderContent = () => {
    switch (appState) {
      case AppState.SETUP_REQUIRED:
        return <SetupInstructions />;
      case AppState.CONNECTIONS:
        return <ConnectAccounts onComplete={handleConnectionsComplete} gapiReady={gapiReady} />;
      case AppState.PROFILE:
        return <UserProfile onSubmit={handleProfileSubmit} initialData={userProfile} />;
      case AppState.CAPTURE:
        return <ImageCapture onCapture={handleImageCapture} onEditProfile={handleProfileEdit} />;
      case AppState.PROCESSING:
        return <Loader message="Analyzing image and crafting responses..." />;
      case AppState.RESULTS:
        return extractedData && googleUser && tokenClient && (
          <ResultsDisplay 
            data={extractedData} 
            onReset={handleReset} 
            googleUser={googleUser}
            tokenClient={tokenClient}
            gapiReady={gapiReady}
          />
        );
      default:
        return <p>Invalid state</p>;
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg text-dark-text flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <header className="w-full max-w-4xl text-center mb-8">
         <div className="flex items-center justify-center gap-3 mb-2">
            <SparklesIcon className="w-8 h-8 text-brand-secondary" />
            <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-brand-primary to-brand-secondary text-transparent bg-clip-text">
                Gemini Contact Scanner
            </h1>
        </div>
        <p className="text-dark-text-secondary text-sm sm:text-base">
          Instantly connect with new contacts. Scan, extract, and engage.
        </p>
      </header>
      <main className="w-full max-w-4xl">
        {error && !isSetupRequired && (
            <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded-lg relative mb-6" role="alert">
                <strong className="font-bold">Error: </strong>
                <span className="block sm:inline">{error}</span>
            </div>
        )}
        {renderContent()}
      </main>
    </div>
  );
};

export default App;