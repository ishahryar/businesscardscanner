import React, { useState, useEffect } from 'react';
import ClipboardIcon from './icons/ClipboardIcon';

const SetupInstructions: React.FC = () => {
  const [origin, setOrigin] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    // This code runs on the client-side after the component mounts
    setOrigin(window.location.origin);
  }, []);

  const handleCopy = () => {
    if (origin) {
      navigator.clipboard.writeText(origin);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="w-full mt-8 pt-6 border-t border-dark-border animate-fade-in text-left">
      <h2 className="text-xl font-bold mb-3 text-white">Troubleshooting Sign-In</h2>
      <p className="text-dark-text-secondary mb-6">
        Sign-in issues are almost always caused by an <code className="bg-red-900/50 text-red-300 px-1 rounded mx-1">origin_mismatch</code> error. This means the application's URL needs to be authorized in your Google Cloud project.
      </p>

      {origin && (
        <div className="bg-brand-primary/10 border border-brand-primary/50 text-dark-text px-4 py-3 rounded-lg relative mb-6">
          <h3 className="font-bold text-white">Your App's Origin URL</h3>
          <p className="text-sm text-dark-text-secondary mb-2">You must add this exact URL in the steps below.</p>
          <div className="flex items-center gap-2">
            <code className="bg-gray-700 px-2 py-1 rounded text-white flex-grow break-all">{origin}</code>
            <button
              onClick={handleCopy}
              title="Copy URL"
              className="p-2 rounded-md bg-gray-700 hover:bg-gray-600 transition text-dark-text"
            >
              {copied ? <span className="text-xs text-green-400">Copied!</span> : <ClipboardIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      )}

      <div className="space-y-4 text-dark-text">
        <h3 className="text-lg font-semibold text-brand-primary">How to Fix Origin Errors:</h3>
        <ol className="list-decimal list-inside space-y-3 bg-gray-800 p-4 rounded-lg">
          <li>
            Go to the Google Cloud Console Credentials page:
            <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline ml-1">
              console.cloud.google.com/apis/credentials
            </a>
          </li>
          <li>
            Select the project that contains your OAuth Client ID.
          </li>
          <li>
            Under the "OAuth 2.0 Client IDs" section, click on the <strong>Name</strong> of the client ID you are using for this application.
          </li>
          <li>
            On the configuration page, find the "Authorized JavaScript origins" section.
          </li>
          <li>
            Click <strong>+ ADD URI</strong> and paste your app's origin URL (shown above).
          </li>
           <li>
            Click the <strong>Save</strong> button at the bottom of the page.
          </li>
           <li>
            Return here and refresh the page to try signing in again.
          </li>
        </ol>
      </div>
    </div>
  );
};

export default SetupInstructions;