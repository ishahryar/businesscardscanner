import React, { useEffect, useRef, useState } from 'react';
import { GoogleUser, TokenClient } from '../types';
import MailIcon from './icons/MailIcon';
import { GOOGLE_CLIENT_ID } from '../config'; // Import from config file
import SpinnerIcon from './icons/SpinnerIcon';
import SetupInstructions from './SetupInstructions';

// This is required by Google's library, loaded from index.html.
declare const google: any;

interface ConnectAccountsProps {
  onComplete: (user: GoogleUser, client: TokenClient) => void;
  gapiReady: boolean;
}

const ConnectAccounts: React.FC<ConnectAccountsProps> = ({ onComplete, gapiReady }) => {
  const signInButtonRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [isGsiLoaded, setIsGsiLoaded] = useState(false);
  const [showTroubleshooting, setShowTroubleshooting] = useState(false);

  // Poll for the Google Sign-In (GSI) script to be loaded, as it's asynchronous.
  useEffect(() => {
    const interval = setInterval(() => {
      if (typeof google !== 'undefined' && google.accounts) {
        setIsGsiLoaded(true);
        clearInterval(interval);
      }
    }, 100);
    return () => clearInterval(interval);
  }, []);

  // Initialize the Sign-In button once the GSI script is ready.
  useEffect(() => {
    if (!isGsiLoaded) {
      return;
    }
    
    const handleCredentialResponse = async (response: any) => {
      try {
        // Decode JWT to get user profile
        const decodedToken: { email: string, name: string, picture: string } = JSON.parse(atob(response.credential.split('.')[1]));
        
        const user: GoogleUser = {
          email: decodedToken.email,
          name: decodedToken.name,
          picture: decodedToken.picture
        };

        // Initialize the token client for getting access tokens for the Gmail API
        const tokenClient = google.accounts.oauth2.initTokenClient({
          client_id: GOOGLE_CLIENT_ID,
          scope: 'https://www.googleapis.com/auth/gmail.compose',
          callback: '', // The callback is set dynamically before each API request
        });

        onComplete(user, tokenClient);
      } catch (e) {
          console.error("Error handling Google credential response:", e);
          setError("Failed to process Google sign-in. Please try again.");
      }
    };

    try {
      google.accounts.id.initialize({
        client_id: GOOGLE_CLIENT_ID,
        callback: handleCredentialResponse,
      });

      if (signInButtonRef.current) {
          // Ensure the button is empty before rendering
          if (signInButtonRef.current.childElementCount === 0) {
              google.accounts.id.renderButton(
                signInButtonRef.current,
                { theme: 'filled_blue', size: 'large', type: 'standard', text: 'signin_with' }
              );
          }
      }
    } catch(err) {
        console.error("Google Accounts initialization error:", err);
        setError("Could not initialize Google Sign-In. Check your Client ID configuration.")
    }
    
  }, [isGsiLoaded, onComplete]);

  const renderSignInButton = () => {
     if (error) {
         return <div className="text-red-400 text-center p-4 bg-red-900/50 rounded-lg">{error}</div>;
     }
     if (!isGsiLoaded) {
         return (
            <div className="flex items-center justify-center gap-2 text-dark-text-secondary">
                <SpinnerIcon className="animate-spin h-5 w-5" />
                <span>Initializing Sign-In...</span>
            </div>
         );
     }
     return <div ref={signInButtonRef} id="google-signin-button"></div>;
  }

  return (
    <div className="bg-dark-card border border-dark-border rounded-lg p-6 sm:p-8 animate-fade-in">
      <h2 className="text-2xl font-bold mb-2 text-white">Connect Your Account</h2>
      <p className="text-dark-text-secondary mb-8">
        To create email drafts, please sign in with your Google account. This is a secure process handled by Google.
      </p>

      <div className="flex flex-col items-center justify-center space-y-6">
        <div className="flex items-center gap-3 p-4 bg-gray-800 rounded-lg border border-dark-border w-full">
            <MailIcon className="w-6 h-6 text-dark-text-secondary" />
            <span className="font-semibold text-white">Gmail Integration</span>
        </div>
        
        {renderSignInButton()}
        
        <div className="text-center w-full pt-4">
          <button onClick={() => setShowTroubleshooting(true)} className="text-sm text-blue-400 hover:underline">
              Sign-in not working? Click here for troubleshooting.
          </button>
        </div>

        <p className="text-sm text-dark-text-secondary text-center">
            For WhatsApp, the app will prepare a message and open it on your device for you to send.
        </p>

        {showTroubleshooting && <SetupInstructions />}
      </div>
    </div>
  );
};

export default ConnectAccounts;